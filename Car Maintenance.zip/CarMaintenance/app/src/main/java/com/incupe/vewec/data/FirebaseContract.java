package com.incupe.vewec.data;

public class FirebaseContract {
	public static final class FirebaseMaintenanceDetailsEntry {
		public static final int INSPECT = 0;
		public static final int REPLACE = 1;
	}
}
